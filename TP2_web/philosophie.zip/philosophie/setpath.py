#!/usr/bin/python3

"""Paramétrage du path. Ne pas modifier"""

import sys

sys.path.append("/infres/sr/amarilli/.local/lib/python3.4/site-packages/")
sys.path.append("/infres/sr/amarilli/.local/lib/python3.4/site-packages/bs4/")
sys.path.append("/infres/sr/amarilli/.local/lib/python3.4/site-packages/flask/")

